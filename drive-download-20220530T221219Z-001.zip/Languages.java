import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public enum Languages { 
	Arabic, English, Franch;
	

	}
	

