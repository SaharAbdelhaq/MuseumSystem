public enum MuseumWorkingDays {
	Saturday, Sunday, Monday, Tusday,Wednesday, Thursday, Friday	
}
